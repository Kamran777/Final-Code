export class Comments{
    rating: number;
    comment: string;
    author: string;
    date: string;
}